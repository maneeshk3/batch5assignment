select * from WTpart;
select * from WTPartmaster;
 
select wtpm.name, wtpm.wtpartnumber,prod.namecontainerinfo, wtp.versionida2versioninfo,wtp.iterationida2iterationinfo,wtp.statestate, wtp.classnamekeya2state, wtp.* 
from wtpartmaster wtpm, wtpart wtp,PDMLinkProduct prod where 
wtpm.ida2a2 = ida3masterreference and
prod.ida2a2 = wtp.ida3containerreference and
wtpm.wtpartnumber = '0000000004';