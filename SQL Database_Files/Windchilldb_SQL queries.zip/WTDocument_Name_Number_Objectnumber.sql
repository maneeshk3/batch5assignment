select * from wtdocument;
select * from wtdocumentmaster;

select * from wtdocumentmaster m
join wtdocument d on m.ida2a2 = d.ida3masterreference
where wtdocumentnumber = '0000000005';
