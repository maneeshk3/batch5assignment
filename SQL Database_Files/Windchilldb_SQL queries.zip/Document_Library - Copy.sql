select * from wtlibrary wtl, wtdocumentmaster wtd
where wtl.ida2a2 = wtd.ida3containerreference;

select wtl.NAMECONTAINERINFO from wtlibrary wtl, wtdocumentmaster wtd
where wtl.ida2a2 = wtd.ida3containerreference
and wtdocumentnumber = '0000000061';