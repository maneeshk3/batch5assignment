select * from WTDocument;
select * from WTDocumentmaster;
 
select wtdm.name, wtdm.wtDocumentnumber,prod.namecontainerinfo, wtd.versionida2versioninfo,wtd.iterationida2iterationinfo,wtd.statestate, wtd.classnamekeya2state , wtd.* from 
wtDocumentmaster wtdm, wtDocument wtd,PDMLinkProduct prod where 
wtdm.ida2a2 = ida3masterreference and
prod.ida2a2 = wtd.ida3containerreference and
wtdm.wtDocumentnumber = '0000000043';