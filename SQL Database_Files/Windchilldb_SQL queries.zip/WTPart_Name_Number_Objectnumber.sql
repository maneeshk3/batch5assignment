select * from WTpart;
select * from WTPartmaster;

select * from wtpartmaster 
join wtpart on wtpart.ida3masterreference = wtpartmaster.ida2a2
where wtpartnumber = 'WCDS000759';