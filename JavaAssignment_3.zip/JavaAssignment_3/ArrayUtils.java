public class ArrayUtils {

    // Method to reverse an array
    public static void reverseArray(int[] array) {
        int start = 0;           // Start index
        int end = array.length - 1; // End index

        // Swap elements from start to end
        while (start < end) {
            // Swap array[start] with array[end]
            int temp = array[start];
            array[start] = array[end];
            array[end] = temp;

            // Move towards the middle
            start++;
            end--;
        }
    }

    // Method to print the array
    public static void printArray(int[] array) {
        for (int value : array) {
            System.out.print(value + " ");
        }
        System.out.println(); // Move to the next line after printing the array
    }

    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5}; // Example array

        System.out.println("Original array:");
        printArray(numbers); // Print the original array

        reverseArray(numbers); // Reverse the array

        System.out.println("Reversed array:");
        printArray(numbers); // Print the reversed array
    }
}
