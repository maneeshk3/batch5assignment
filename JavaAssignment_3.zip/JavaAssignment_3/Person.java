public class Person {
    
    private String name;
	private String email;
    private int age;

    public void setinfo(String name, int age, String email) {
        this.name = name;
        this.age = age;
        this.email = email;
    }

    public void printinfo() {
        System.out.println(name);
        System.out.println(age);
        System.out.println(email);
    }
	
	public static void main(String[] args){
		Person p1 = new Person();
		p1.setinfo("Dakshit",2,"Dakshit@gmail.com");
		p1.printinfo();
	}
}