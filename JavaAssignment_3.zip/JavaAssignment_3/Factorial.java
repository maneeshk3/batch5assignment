public class Factorial {

    // Recursive method to calculate factorial
    public static int factorial(int n) {
        // Base case: factorial of 0 is 1
        if (n == 0) {
            return 1;
        } else {
            // Recursive case: n! = n * (n-1)!
            return n * factorial(n - 1);
        }
    }

    public static void main(String[] args) {
        int number = 10; // You can change this to any non-negative integer

        // Calculate factorial using the recursive method
        int result = factorial(number);

        // Print the result
        System.out.println("Factorial of " + number + " is " + result);
    }
}
