public class DataTypeExample {
    public static void main(String[] args) {
        // Primitive Data Type
        int age = 30; // Stores the value directly
        System.out.println("Primitive Age: " + age); // Outputs: Primitive Age: 30
        
        // Non-Primitive Data Type
        Person person = new Person("Dakshit", 28); // person stores a reference to the Person object
        System.out.println("Non-Primitive Person: " + person); // Outputs: Non-Primitive Person: Person{name='Dakshit', age=28}
        
        // Modifying the non-primitive data
        person.setAge(29); // Modifying the object through the reference
        System.out.println("Updated Non-Primitive Person: " + person); // Outputs: Updated Non-Primitive Person: Person{name='Dakshit', age=29}
        
        // Demonstrating reference behavior
        Person anotherPerson = person; // anotherPerson references the same object
        anotherPerson.setName("Shiva"); // Changing name via another reference
        System.out.println("Original Person After Change: " + person); // Outputs: Original Person After Change: Person{name='Shiva', age=29}
    }
}

// Person class to demonstrate non-primitive data type
class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public String toString() {
        return "Person{name='" + name + "', age=" + age + '}';
    }
}
