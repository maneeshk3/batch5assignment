public class Book{
    
    String title;
    String author;
    int pagenumbers;
   
    public Book(String title,String author){
        this.title = title;
        this.author = author;
        this.pagenumbers = 0;
    }
    
 
    public Book(String title,String author,int pagenumbers){
        this.title = title;
        this.author = author;
        this.pagenumbers = pagenumbers;
        
    }
    
    public void printresult(){
        System.out.println("Title: " + title);
        System.out.println("Author: " + author);
        System.out.println("Number of Pages: " + pagenumbers);
        
    }
    
    public static void main(String[] args) {
		Book book1 = new Book("A","XYZ");
		book1.printresult();
		
		Book book2 = new Book("B","PQR",360);
		book2.printresult();
		
	}
}


