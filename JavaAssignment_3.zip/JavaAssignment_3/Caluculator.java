public class Caluculator {

   
    public static int multiply(int a, int b) {
        return a * b;
    }
    
 
    public static double multiply(double a, double b) {
        return a * b;
    }
    
 
    public static int add(int a, int b) {
        return a + b;
    }
    
    
    public static double add(double a, double b) {
        return a + b;
    }
    
   
    public static int subtract(int a, int b) {
        return a - b;
    }
    
 
    public static double subtract(double a, double b) {
        return a - b;
    }
    
    // Method to divide two integers
    public static int divide(int a, int b) {
        // Simple integer division; assumes b != 0
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        }
        return a / b;
    }
    
    // Overloaded method to divide two doubles
    public static double divide(double a, double b) {
        // Double division; assumes b != 0
        if (b == 0) {
            throw new ArithmeticException("Cannot divide by zero");
        }
        return a / b;
    }
    
    public static void main(String[] args) {
        // Using integer methods
        int Res1 = multiply(6, 3);
        int Res2 = add(6, 3);
        int Res3 = subtract(6, 3);
        int Res4 = divide(6, 3);
        
        System.out.println("Integer Multiplication: " + Res1);
        System.out.println("Integer Addition: " + Res2);
        System.out.println("Integer Subtraction: " + Res3);
        System.out.println("Integer Division: " + Res4);
        
        // Using double methods
        double Res5 = multiply(6.5, 3.2);
        double Res6 = add(6.5, 3.2);
        double Res7 = subtract(6.5, 3.2);
        double Res8 = divide(6.5, 3.2);
        
        System.out.println("Double Multiplication: " + Res5);
        System.out.println("Double Addition: " + Res6);
        System.out.println("Double Subtraction: " + Res7);
        System.out.println("Double Division: " + Res8);
    }
}



